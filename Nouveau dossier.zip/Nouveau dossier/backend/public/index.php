<?php

require '../config/init_database.php';

?>