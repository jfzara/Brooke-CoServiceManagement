
  export const environment = {
    production: false,
    apiUrl: 'http://localhost/backend/public/api'  // Mise à jour de l'URL
  };
